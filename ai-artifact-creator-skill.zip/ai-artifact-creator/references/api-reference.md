# Anthropic API Reference — for AI-powered artifacts

This is the full mechanical reference. Read the relevant section before writing a fetch call — don't write these from memory, the shapes are easy to get subtly wrong (especially structured JSON and tool use).

## Basic call

```javascript
const response = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "claude-sonnet-4-6", // always this exact string
    max_tokens: 1000,           // always 1000, pre-configured server-side
    messages: [
      { role: "user", content: "Your prompt here" }
    ],
  })
});

const data = await response.json();
```

Never pass an API key or auth header — it's injected automatically. Never tell the user they need one.

## Response shape

`data.content` is an **array of blocks**, not a string:

```json
{
  "content": [
    { "type": "text", "text": "Claude's response here" }
    // could also include: tool_use, tool_result, image, document blocks
  ]
}
```

Always extract text by mapping over the array:

```javascript
const text = data.content
  .filter(block => block.type === "text")
  .map(block => block.text)
  .join("\n");
```

Never assume `data.content[0].text` is the whole answer — if tools were used, there may be `tool_use` blocks mixed in, and the text may be split across multiple blocks.

## System prompts

Use the top-level `system` field, not a message with `role: "system"`:

```javascript
body: JSON.stringify({
  model: "claude-sonnet-4-6",
  max_tokens: 1000,
  system: "You are a terse, sarcastic movie critic. Keep responses under 3 sentences.",
  messages: [{ role: "user", content: userInput }]
})
```

## Structured JSON output

When the app needs structured data to drive UI (lists, scores, categorized items), force JSON in the system prompt and defensively parse:

```javascript
system: `Respond with ONLY a valid JSON object, no markdown code fences, no preamble or explanation. Format:
{"items": [{"name": string, "category": string, "score": number}]}`,
```

```javascript
try {
  const raw = data.content.map(b => b.text || "").join("");
  const clean = raw.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(clean);
  // use parsed.items
} catch (err) {
  console.error("Failed to parse AI response:", err);
  setError("The AI response couldn't be processed. Please try again.");
}
```

Always wrap the parse in try/catch and show a user-visible fallback — never let a parse failure crash the render or silently produce a blank UI.

## Context / state management — the most common bug

**There is no memory between completions.** Every single call is fully stateless from the API's point of view. If the app has any notion of "earlier in this conversation/game," the calling code is responsible for resending all of it, every time.

### Multi-turn conversation

```javascript
// Keep history in React state (or a JS array in HTML mode)
const history = [
  { role: "user", content: "Hello" },
  { role: "assistant", content: "Hi! How can I help?" },
  { role: "user", content: "Create a task in Asana" }
];

const newUserMessage = { role: "user", content: "Use the Engineering workspace" };

// Send the FULL history plus the new message every time
body: JSON.stringify({
  model: "claude-sonnet-4-6",
  max_tokens: 1000,
  messages: [...history, newUserMessage]
})
```

After getting a response, append both the user message and the assistant's reply to `history` before the next call — not just the user message.

### Stateful apps (games, simulations, multi-step tools)

Serialize the full state into the prompt and ask for both an update and a structured result:

```javascript
const gameState = {
  player: { name: "Hero", health: 80, inventory: ["sword"] },
  history: ["Entered forest", "Fought goblin"]
};

const prompt = `
Given this state: ${JSON.stringify(gameState)}
Last action: "Use health potion"
Respond ONLY with a JSON object containing:
- updatedState
- actionResult
- availableActions
`;
```

Then store `updatedState` back into component state for the next turn. The pattern is always: *state lives in the artifact's own JS/React state; the API call is a pure function of (state + new input) → (new state + output).*

## Web search tool

For apps that need current information (news, fact-checking, live research):

```javascript
body: JSON.stringify({
  model: "claude-sonnet-4-6",
  max_tokens: 1000,
  messages: [{ role: "user", content: "What are the latest developments in fusion energy this week?" }],
  tools: [
    { type: "web_search_20250305", name: "web_search" }
  ]
})
```

The response may interleave text and search-related content blocks — process all blocks, not just the first:

```javascript
const fullResponse = data.content
  .map(item => (item.type === "text" ? item.text : ""))
  .filter(Boolean)
  .join("\n");
```

## File inputs (PDF / image)

Convert to base64 and send as a `document` or `image` content block within a user message.

### PDF

```javascript
const base64Data = await new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(reader.result.split(",")[1]);
  reader.onerror = () => reject(new Error("Read failed"));
  reader.readAsDataURL(file);
});

messages: [
  {
    role: "user",
    content: [
      { type: "document", source: { type: "base64", media_type: "application/pdf", data: base64Data } },
      { type: "text", text: "Summarize this document." }
    ]
  }
]
```

### Image

```javascript
messages: [
  {
    role: "user",
    content: [
      { type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageData } },
      { type: "text", text: "Describe this image." }
    ]
  }
]
```

## Error handling pattern

Always wrap calls in try/catch; if expecting JSON, strip code fences before parsing:

```javascript
try {
  const response = await fetch("https://api.anthropic.com/v1/messages", { /* ... */ });
  if (!response.ok) {
    throw new Error(`API returned ${response.status}`);
  }
  const data = await response.json();
  const text = data.content.map(i => i.text || "").join("\n");
  // ... use text
} catch (err) {
  console.error("Claude API error:", err);
  setError("Something went wrong talking to the AI. Please try again.");
} finally {
  setLoading(false);
}
```

## React-specific gotchas

- **Never use `<form>`** — use `onClick`/`onChange` handlers directly:
  ```javascript
  <button onClick={handleSubmit}>Run</button>
  ```
- Default export required, no required props (or give them sane defaults).
- No `localStorage`/`sessionStorage` for app state — use `useState`/`useReducer`. See `persistent-storage.md` if cross-session persistence is genuinely needed.
