# Persistent storage for AI-powered artifacts

This is a **separate mechanism from the Anthropic API**. It's for when an AI-powered artifact needs to remember things *after the artifact is closed and reopened* — a saved chat log, an AI-judged leaderboard, a journal of past AI-generated entries. Don't reach for this by default; most AI artifacts only need in-memory React state for the duration of one session.

## When to use it

Use `window.storage` when the artifact is explicitly a journal, tracker, leaderboard, or any tool where the user would reasonably expect "what I did last time" to still be there.

Don't use it just to cache API responses within a single session — that's what React state is for.

## API

```javascript
await window.storage.get(key, shared?)     // → {key, value, shared} | null
await window.storage.set(key, value, shared?)
await window.storage.delete(key, shared?)
await window.storage.list(prefix?, shared?) // → {keys, prefix?, shared} | null
```

- **Personal** (`shared: false`, default): only the current user sees it.
- **Shared** (`shared: true`): visible to *all* users of the artifact — if used, tell the user their data will be visible to others.
- Keys: hierarchical, under 200 chars, no whitespace/slashes/quotes (e.g. `chatlog:session1`, `leaderboard:alice`).
- Values: text/JSON only, under 5MB each.
- Always specify `shared` explicitly.

## Pattern: saving an AI-judged leaderboard entry

```javascript
async function saveScore(name, score, aiVerdict) {
  try {
    const entry = { name, score, verdict: aiVerdict, timestamp: Date.now() };
    const result = await window.storage.set(`scores:${name}`, JSON.stringify(entry), true); // shared
    if (!result) console.error("Save failed");
  } catch (err) {
    console.error("Storage error:", err);
  }
}
```

## Pattern: loading saved chat history on mount

```javascript
useEffect(() => {
  (async () => {
    try {
      const result = await window.storage.get("chat-history");
      if (result) setHistory(JSON.parse(result.value));
    } catch (err) {
      // key doesn't exist yet — that's fine, start fresh
      console.log("No saved history yet");
    }
  })();
}, []);
```

Note: `get` on a missing key **throws**, it doesn't return `null` silently in all cases — always wrap in try/catch, never assume.

## Combine related fields into one key

If a feature updates several pieces of state together (e.g., a journal entry's text + mood + AI-generated reflection), store them as one JSON object under one key rather than three separate `set` calls — this avoids unnecessary round trips and partial-write inconsistency.

```javascript
// Good
await window.storage.set(`entry:${id}`, JSON.stringify({ text, mood, reflection }));

// Avoid
await window.storage.set(`entry-text:${id}`, text);
await window.storage.set(`entry-mood:${id}`, mood);
await window.storage.set(`entry-reflection:${id}`, reflection);
```

## Always provide a reset

Any artifact using persistent storage should give the user a visible way to clear their own data (a "reset" button calling `delete` on the relevant keys), since there's no other UI for them to manage it.
