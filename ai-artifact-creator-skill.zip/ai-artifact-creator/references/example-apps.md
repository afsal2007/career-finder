# Example apps — starting skeletons

Three worked patterns covering the most common shapes of AI-powered artifact. Adapt, don't copy verbatim — but the structure (state shape, loading/error handling, call pattern) is the part worth reusing as-is.

## 1. Multi-turn chatbot (React)

Covers: conversational assistants, NPC dialogue, tutors, debate partners — anything needing full history resent every turn.

```jsx
import { useState } from "react";

export default function ChatBot() {
  const [history, setHistory] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input };
    const newHistory = [...history, userMsg];
    setHistory(newHistory);
    setInput("");
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: "You are a friendly, concise assistant.",
          messages: newHistory,
        }),
      });
      if (!response.ok) throw new Error(`API error ${response.status}`);
      const data = await response.json();
      const text = data.content.filter(b => b.type === "text").map(b => b.text).join("\n");
      setHistory([...newHistory, { role: "assistant", content: text }]);
    } catch (err) {
      setError("Couldn't get a response. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-96 max-w-md mx-auto border rounded-lg p-4 gap-2">
      <div className="flex-1 overflow-y-auto space-y-2">
        {history.map((m, i) => (
          <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
            <span className="inline-block px-3 py-1 rounded-lg bg-gray-100">{m.content}</span>
          </div>
        ))}
        {loading && <div className="text-gray-400 text-sm">Thinking…</div>}
        {error && <div className="text-red-500 text-sm">{error}</div>}
      </div>
      <div className="flex gap-2">
        <input
          className="flex-1 border rounded px-2 py-1"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Type a message…"
        />
        <button
          className="px-3 py-1 bg-blue-500 text-white rounded disabled:opacity-50"
          onClick={sendMessage}
          disabled={loading || !input.trim()}
        >
          Send
        </button>
      </div>
    </div>
  );
}
```

Key things to notice: `newHistory` (not stale `history`) is what's sent to the API and is also what gets the assistant reply appended to it — this avoids stale-state bugs from React's async `setState`.

## 2. Structured-JSON content generator (HTML)

Covers: idea generators, quiz generators, anything that fills a list/grid of UI from one AI call.

```html
<div id="app" style="max-width: 500px; margin: 0 auto; font-family: system-ui;">
  <input id="topic" placeholder="Enter a topic…" style="width: 70%; padding: 8px;" />
  <button id="generateBtn" style="padding: 8px 16px;">Generate Ideas</button>
  <div id="status" style="color: #888; margin-top: 8px;"></div>
  <ul id="results" style="margin-top: 12px;"></ul>
</div>

<script>
  const btn = document.getElementById("generateBtn");
  const topicInput = document.getElementById("topic");
  const status = document.getElementById("status");
  const results = document.getElementById("results");

  btn.addEventListener("click", async () => {
    const topic = topicInput.value.trim();
    if (!topic) return;
    btn.disabled = true;
    status.textContent = "Generating…";
    results.innerHTML = "";

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: `Respond with ONLY valid JSON, no markdown fences, no preamble. Format:
{"ideas": [{"title": string, "description": string}]}`,
          messages: [{ role: "user", content: `Give me 5 creative ideas about: ${topic}` }],
        }),
      });
      if (!response.ok) throw new Error(`API error ${response.status}`);
      const data = await response.json();
      const raw = data.content.map(b => b.text || "").join("");
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);

      parsed.ideas.forEach(idea => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${idea.title}</strong> — ${idea.description}`;
        results.appendChild(li);
      });
      status.textContent = "";
    } catch (err) {
      status.textContent = "Something went wrong. Please try again.";
      console.error(err);
    } finally {
      btn.disabled = false;
    }
  });
</script>
```

## 3. Web-search-powered research tool (React)

Covers: current-events lookups, fact-checking tools, "what's the latest on X" apps.

```jsx
import { useState } from "react";

export default function ResearchTool() {
  const [query, setQuery] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const research = async () => {
    if (!query.trim() || loading) return;
    setLoading(true);
    setError(null);
    setAnswer("");

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{ role: "user", content: query }],
          tools: [{ type: "web_search_20250305", name: "web_search" }],
        }),
      });
      if (!response.ok) throw new Error(`API error ${response.status}`);
      const data = await response.json();
      const text = data.content
        .map(item => (item.type === "text" ? item.text : ""))
        .filter(Boolean)
        .join("\n");
      setAnswer(text || "No answer returned.");
    } catch (err) {
      setError("Research failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto p-4 space-y-3">
      <div className="flex gap-2">
        <input
          className="flex-1 border rounded px-2 py-1"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && research()}
          placeholder="Ask about current events…"
        />
        <button
          className="px-3 py-1 bg-blue-500 text-white rounded disabled:opacity-50"
          onClick={research}
          disabled={loading || !query.trim()}
        >
          {loading ? "Searching…" : "Search"}
        </button>
      </div>
      {error && <div className="text-red-500 text-sm">{error}</div>}
      {answer && <div className="whitespace-pre-wrap text-sm border rounded p-3 bg-gray-50">{answer}</div>}
    </div>
  );
}
```
