---
name: ai-artifact-creator
description: Build AI-powered artifacts that call the Anthropic API directly from generated code ("Claude inside Claude," "Claudeception," AI-powered apps). Use this skill whenever the user wants an artifact that itself uses an LLM to do something dynamic — chatbots, AI assistants, content generators, classifiers, summarizers, game NPCs with AI dialogue, recommendation tools, AI-judged quizzes, or any tool where the artifact's logic depends on calling Claude at runtime rather than just running static code. Trigger on phrases like "make an AI-powered app," "build a chatbot artifact," "use Claude inside this artifact," "an app that uses AI to generate/judge/respond," or any request for an interactive tool whose core feature requires natural-language understanding/generation rather than deterministic logic. Do NOT use this for artifacts that are purely deterministic (calculators, static dashboards, games with fixed rules) — only when the artifact needs to call an LLM at runtime.
---

# AI-Powered Artifact Creator

Build artifacts (React or HTML) that call the Anthropic API from within the artifact's own code, so the artifact has live AI behavior — generation, judgment, conversation, classification — running inside it.

## When this applies

Use this skill when the artifact's *core behavior* requires an LLM call at runtime: it needs to understand free text, generate varied/creative content on demand, make a judgment call, hold a conversation, or react intelligently to arbitrary user input. If the logic can be written as plain deterministic code (sorting, math, fixed rules, static lookups), don't reach for this skill — just build a normal artifact.

Good fits: chatbots, AI dungeon masters / NPC dialogue, writing coaches, debate partners, quiz graders that judge free-text answers, content/idea generators, AI-powered search-and-summarize tools, code reviewers, language tutors, sentiment/classification tools, "rate my X" judges.

Not a fit: a todo list, a unit converter, a static chart, a game with fixed win conditions, a form that just validates input.

## Before writing any code

1. Check `/mnt/skills/public/frontend-design/SKILL.md` if the artifact has any real UI surface — it covers visual design tokens and styling constraints for this environment. Read it before writing the artifact, not after.
2. Decide React vs HTML based on the task, not habit:
   - **React** — when there's meaningful client-side state across turns (chat history, scores, multi-step flows), or the UI needs componentized structure.
   - **Plain HTML/JS** — when it's simpler: a single input → single AI response, no complex state, or you want to avoid React's import/hook constraints.
   - Either way, this is a single-file artifact. CSS and JS live in the same file as the markup/component.
3. Skim `references/api-reference.md` in this skill for the exact request/response shapes before writing the fetch call — don't write it from memory, the shapes (especially tool use and structured JSON output) are easy to get subtly wrong.

## Core mechanics (the part that's easy to get wrong)

- **Endpoint**: `https://api.anthropic.com/v1/messages`, called with plain `fetch`. No API key is ever passed — it's injected automatically. Never add an `Authorization` or `x-api-key` header, and never tell the user they need to supply a key.
- **Model string**: always `"claude-sonnet-4-6"`. Don't use any other model name.
- **`max_tokens`**: this is pre-configured server-side for this environment — just set it to `1000` in every request regardless of expected response length.
- **No memory between calls**: every request is stateless. If the app needs conversation history, multi-turn context, or game state, the calling code must serialize and resend the *entire* relevant history/state in `messages` on every single call. This is the single most common bug — see `references/api-reference.md` § Context Management.
- **Response shape**: `data.content` is an array of blocks (`text`, `tool_use`, etc.), not a single string. Always map/join over it rather than assuming `data.content[0].text`. If tools are used, the model may emit `tool_use` blocks that need a follow-up turn.
- **JSON output**: if the app needs structured data back (to drive UI, fill a list, etc.), the system prompt must explicitly instruct "respond with ONLY valid JSON, no markdown fences, no preamble," and the calling code should still defensively strip ` ```json ` fences before `JSON.parse`. Never skip the try/catch.
- **Web search tool**: available via the `web_search_20250305` tool type if the app needs live/current info (news, fact-checking, research). See the reference for the exact tools array shape.
- **Files (PDF/image) as input**: base64-encode and send as `document`/`image` content blocks if the app needs to let the user feed Claude a file or screenshot.

## React-specific constraints

- No `<form>` tags — use `onClick`/`onChange` handlers directly, or the artifact will break.
- Default export, no required props.
- No `localStorage`/`sessionStorage` — keep all state in React state (`useState`/`useReducer`). This matters more here than in static artifacts, since AI app state (chat logs, generated content) is exactly what people expect to persist, and it's tempting to reach for browser storage. Don't.
- Persisting data across *sessions* (not just within one render) is possible via `window.storage` — see `references/persistent-storage.md` if the app needs to remember things after the artifact is closed and reopened (e.g., a saved chat log, a leaderboard of AI-judged scores). This is a different mechanism from the Anthropic API and is opt-in only when the user actually needs cross-session persistence.

## Always build in: loading state, errors, and abuse-resistance

Every AI-powered artifact must handle:
1. **Loading state** — disable the input/button and show a spinner or "Thinking…" while the fetch is in flight. An AI call takes a few seconds; a frozen-looking UI with no feedback reads as broken.
2. **Error handling** — wrap every API call in try/catch and show a user-visible error message (not just a console log) if the call fails.
3. **Empty/invalid input guards** — don't fire a request on empty input.
4. **Rate-limit-conscious UX** — don't auto-fire requests in a tight loop (e.g., on every keystroke). Trigger on explicit action (button click, submit, debounced input).

These aren't optional polish — an AI artifact that silently hangs or silently fails on error is the most common failure mode users report.

## Workflow

1. Confirm what AI behavior is actually needed (generation? judgment? conversation? extraction?) and whether structured JSON output is required to drive the UI.
2. Pick React or HTML per the guidance above.
3. Read `/mnt/skills/public/frontend-design/SKILL.md` for visual styling if the UI is non-trivial.
4. Check `references/api-reference.md` for the exact call shape needed (plain text / JSON / tool use / web search / file input) — pick the matching pattern rather than improvising.
5. If a similar app already exists in `references/example-apps.md`, start from that pattern and adapt it rather than writing from scratch.
6. Write the artifact with loading/error/guard states included from the first draft, not bolted on after.
7. Mentally trace through one full interaction (including a failure case) before presenting it.

## Reference files

- `references/api-reference.md` — full API mechanics: endpoint, request/response shapes, JSON-structured output, web search tool, file inputs (PDF/image), context/state management, error handling. Read this before writing any fetch call.
- `references/example-apps.md` — worked examples: a multi-turn chatbot (React), a structured-JSON content generator (HTML), and a web-search-powered research tool. Use these as starting skeletons.
- `references/persistent-storage.md` — when and how to use `window.storage` for cross-session persistence (separate from the Anthropic API itself), for apps like journals, trackers, or leaderboards that need to remember state after the artifact is closed.
